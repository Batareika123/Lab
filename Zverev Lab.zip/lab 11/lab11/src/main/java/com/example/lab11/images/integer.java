package com.example.lab11.images;

public class integer {
}
