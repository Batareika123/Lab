package com.example.lab11;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.text.FontWeight;
import javafx.scene.paint.Color;
import javafx.geometry.Insets;

import java.io.IOException;

public class togle extends Application {
    @Override
    public void start(Stage primaryStage) throws IOException {
        VBox toggleButtonExample = null; {
            Label label = new Label("LABEL");
            label.setFont(Font.font(20));
            label.setPrefSize(400, 50);
            label.setAlignment(Pos.CENTER);

            ToggleButton btn = new ToggleButton();
            btn.setFont(Font.font(20));
            btn.setPrefSize(400, 50);
            btn.setText("Push!");

            btn.setOnAction((event) -> {
                if (btn.isSelected()) {
                    label.setText("ON");
                    label.setFont(Font.font("Tahoma", FontWeight.NORMAL, 30));
                    label.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));
                } else {
                    label.setText("OFF");
                    label.setFont(Font.font("Tahoma", FontWeight.MEDIUM, 30));
                    label.setBackground(new Background(new BackgroundFill(Color.RED, CornerRadii.EMPTY, Insets.EMPTY)));
                }
            });
            VBox vBox = new VBox(20);
            vBox.setPadding(new Insets(50, 100, 50, 100));
            vBox.getChildren().addAll(btn, label);

            StackPane root = new StackPane();
            root.getChildren().add(vBox);

            Scene scene = new Scene(root, 900, 600);

            primaryStage.setTitle("ComboBox");
            primaryStage.setScene(scene);
            primaryStage.show();

        }


    }

    public static void main(String[] args) {
        launch();
    }
}
