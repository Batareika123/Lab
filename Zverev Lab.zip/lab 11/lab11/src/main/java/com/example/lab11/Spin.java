package com.example.lab11;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.Group;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.text.FontWeight;
import javafx.scene.paint.Color;
import javafx.geometry.Insets;

import java.io.IOException;

public class Spin extends Application {
    @Override
    public void start(Stage primaryStage) throws IOException {
        Spinner<Integer> spInt = new Spinner(-100, 100, 0);
        spInt.setStyle("-fx-font-size: 30px");
        spInt.setPrefWidth(170);
        Spinner<Double> spDouble = new Spinner<>(-100.0, 100.0, 1.0, 0.1);
        spDouble.setEditable(true);
        spDouble.setStyle("-fx-font-size: 30px");
        spDouble.setPrefWidth(170);
        Label label = new Label();
        label.setFont(Font.font(30));
        label.setPrefSize(400,100);
        Button btn = new Button();
        btn.setText("Ok");
        btn.setFont(Font.font(30));
        btn.setOnAction((event)->{
            label.setText("integer spinner: " + spInt.getValue() + "\ndouble spinner: " + spDouble.getValue());
        });
        VBox vBox = new VBox(20);
        vBox.setPadding(new Insets(50,100,50,100));
        vBox.getChildren().addAll(spInt, spDouble, btn, label);

        StackPane root = new StackPane();
        root.getChildren().add(vBox);

        Scene scene = new Scene(root, 900, 600);

        primaryStage.setTitle("ComboBox");
        primaryStage.setScene(scene);
        primaryStage.show();

    }
}
