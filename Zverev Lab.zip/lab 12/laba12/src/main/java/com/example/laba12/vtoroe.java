package com.example.laba12;

import java.io.IOException;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class vtoroe extends Application {
    public vtoroe() {
    }

    public void start(Stage primaryStage) throws IOException {
        Group groupChart = new Group();

        class Func {
            private double xmin;
            private double xmax;
            private int step;

            public Func(vtoroe this$0, double min, double max, int numStep) {
                this.xmin = min;
                this.xmax = max;
                this.step = numStep;
            }

            private double f(double x) {
                return (3.0 - 4.0 * x) / (x * x + 1.0);
            }

            public String getName() {
                return "(3 - 4*x)/(x*x+1)";
            }

            public XYChart.Series getSeries() {
                ObservableList<XYChart.Data> datas = FXCollections.observableArrayList();
                double x0 = this.xmin;
                double h = (this.xmax - x0) / (double) this.step;

                for (int i = 0; i < this.step; ++i) {
                    datas.add(new XYChart.Data(x0 + h * (double) i, this.f(x0 + h * (double) i)));
                }

                XYChart.Series series = new XYChart.Series();
                series.setName(this.getName());
                series.setData(datas);
                return series;
            }
        }

        Func f = new Func(this, -5.0, 5.0, 600);
        NumberAxis x = new NumberAxis();
        NumberAxis y = new NumberAxis();
        LineChart<Number, Number> numberLineChart = new LineChart(x, y);
        numberLineChart.setCreateSymbols(false);
        numberLineChart.setLayoutX(400.0);
        numberLineChart.setLayoutY(60.0);
        numberLineChart.setMinHeight(600.0);
        numberLineChart.setMinWidth(600.0);
        numberLineChart.getData().add(f.getSeries());
        groupChart.getChildren().add(numberLineChart);
        StackPane root = new StackPane();
        root.getChildren().add(groupChart);
        Scene scene = new Scene(root, 1000.0, 1000.0);
        primaryStage.setTitle("Linechart");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}