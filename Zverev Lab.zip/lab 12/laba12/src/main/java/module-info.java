module com.example.laba12 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.laba12 to javafx.fxml;
    exports com.example.laba12;
}