public class Programm61 {
    public static void main(String[] args) {
        int i = 50;
        while (i < 202) {
            System.out.println(i);
            i = i + 1;
        }
        }
}
