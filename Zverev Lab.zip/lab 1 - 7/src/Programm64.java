public class Programm64 {
    public static void main(String[] args) {
        int a = (14 - 8) / 2 + 1;
        int b = (8 + 14) / 2 * a;
        System.out.println(b);
    }
}
