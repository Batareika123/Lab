public class Programm65 {
    public static void main(String[] args) {
        int a = (20 * 4) / 2 + 1;
        int b = (4 * 20) * 2 * a;
        System.out.println(b);
    }
}
