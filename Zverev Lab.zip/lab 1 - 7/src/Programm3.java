import java.util.Scanner;
public class Programm3 {
    public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("Vvedite lyiboe slovo ili frazu: ");
    String a = scan.nextLine();
    System.out.println("Vi vveli slovo/frazu: " + a);
    }
}
