public class Programm66 {
    public static void main(String[] args) {

    }
}
