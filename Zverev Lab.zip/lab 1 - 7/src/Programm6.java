import java.util.Scanner;
public class Programm6 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Vvedite drobnoe chislo: ");
        double a = scan.nextDouble();
        System.out.println("Vi vveli chislo: " + a);

    }
}
