public class Programm7 {
    public static void main(String[] args) {
        int a = 10;
        switch (a) {
            case 10:
                System.out.println("Verno");
                break;
            default:
                System.out.println("Neverno");
                break;
        }

    }
    }
