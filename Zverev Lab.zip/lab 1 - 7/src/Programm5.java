import java.util.Scanner;
public class Programm5 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Vvedite lyiboe chislo ili frazu: ");
        String a = scan.next();
        System.out.println("Vi vveli slovo/frazu: " + a);

    }
}
