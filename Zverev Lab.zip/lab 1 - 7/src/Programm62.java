public class Programm62 {
    public static void main(String[] args) {
        int x = 10;
        int y = 100;

        for ( ; x < y; x += 20, y --) ;

        System.out.println ("x raven " + x + " ; y raven " + y);


    }
}
