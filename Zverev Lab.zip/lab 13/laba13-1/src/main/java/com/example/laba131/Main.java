package com.example.laba131;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Main extends Application{
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Simple Model-View");
        Organization org = new Organization("Horns&Hoof", 10 , "International Women's Day", LocalDate.of(2020,3,6),0);
        VBox root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        Organization.ViewOrganization viewOrg = new Organization.ViewOrganization(org);
        root.getChildren().add(viewOrg.getPane());
        Button btn = new Button("+");
        btn.setPrefSize(50,50);
        btn.setOnAction((event)->{
            org.increaseBonus();
            viewOrg.setInform();
        });
        root.getChildren().add(btn);
        Scene scene = new Scene(root,500,500);
        primaryStage.setScene(scene);
        primaryStage.show();
        }
    }


