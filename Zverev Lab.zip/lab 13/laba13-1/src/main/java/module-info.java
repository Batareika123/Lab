module com.example.laba131 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.laba131 to javafx.fxml;
    exports com.example.laba131;
}