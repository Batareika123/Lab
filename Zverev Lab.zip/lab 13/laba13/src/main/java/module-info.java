module com.example.laba13 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.laba13 to javafx.fxml;
    exports com.example.laba13;
}