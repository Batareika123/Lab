package com.example.laba141;

import java.time.format.DateTimeFormatter;

import javafx.beans.property.StringProperty;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import java.time.LocalDate;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;


public class Organization {
    private StringProperty name;
    public StringProperty nameStringProperty(){
        if(name == null){
            name = new SimpleStringProperty();
        }
        return name;
    }
    public final void setName(String value){
        nameStringProperty().set(value);
    }
    public final String getName(){return  nameStringProperty().get();}
    private int personnel;
    private String holiday;
    private LocalDate date;
    private DoubleProperty bonus;
    public DoubleProperty bonusProperty(){
        if(bonus==null){
            bonus = new SimpleDoubleProperty();
        }
        return bonus;
    }
    public final void setBonus(Double value){bonusProperty().set(value);}
    public final Double getBonus(){return bonusProperty().get();}
    public Organization(String name,int personnel, String holiday, LocalDate
            date, double bonus ){
        setName(name);
        this.personnel = personnel;
        this.holiday = holiday;
        this.date = date;
        setBonus(bonus);}
        public int getPersonnel(){return personnel;}
        public String getHoliday(){return holiday;}
        public LocalDate getDate(){return date;}

    }




