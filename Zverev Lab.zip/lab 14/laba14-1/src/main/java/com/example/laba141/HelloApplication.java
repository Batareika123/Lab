package com.example.laba141;

import java.awt.*;
import java.io.IOException;
import java.time.LocalDate;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import javax.swing.*;

public class HelloApplication extends Application {
    private Dialog primaryStage;

    @Override
    public void start(Stage stage) throws IOException {
        primaryStage.setTitle("Simple Model-View Data Binding");
        Organization org = new Organization("Horns&Hoof",10,"International Women's Day", LocalDate.of(2016, 3, 9),0);
        HBox root = new HBox(10);
        ViewOrganization viewOrg = new ViewOrganization(org);
        root.getChildren().add(viewOrg.getPane());
        root.getChildren().add(new Separator(Orientation.VERTICAL));
        root.getChildren().add(editBlock(org));
        Scene scene = new Scene(root, 900, 300);
        primaryStage.show();
        primaryStage.show(); }
    private VBox editBlock(Organization org){
        VBox editPane = new VBox(10);
        editPane.setPadding(new Insets(20));
        Label labelTitle = new Label("Enter name organization\n and bonus");
        labelTitle.setFont(Font.font(20));
        TextField editName = new TextField();
        editName.setFont(Font.font(20));
        editName.setPrefSize(150, 40);
        Spinner<Double> editBonus = new Spinner<>(0, 100, 0, 0.5);
        editBonus.setPrefSize(100, 40);
        editBonus.setStyle("-fx-font-size: 20");
        Button btn = new Button("Edit");
        btn.setFont(Font.font(20));
        btn.setOnAction((ActionEvent event) -> {
            org.setName(editName.getText());
            org.setBonus(editBonus.getValue()); });
        editPane.getChildren().addAll(labelTitle, editName, editBonus,
                btn);
        return editPane; }


    public static void main(String[] args) {
        launch();
    }
}