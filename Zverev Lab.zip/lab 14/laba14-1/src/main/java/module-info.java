module com.example.laba141 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.laba141 to javafx.fxml;
    exports com.example.laba141;
}