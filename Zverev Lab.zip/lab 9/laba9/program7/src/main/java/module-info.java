module com.example.program7 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.program7 to javafx.fxml;
    exports com.example.program7;
}