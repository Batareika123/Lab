package com.example.program6;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {

        Button left = new Button("left");
        BorderPane.setAlignment(left, Pos.CENTER_LEFT);
        Button right = new Button("right");
        BorderPane.setAlignment(right, Pos.CENTER_RIGHT);
        Button top = new Button("Top");
        BorderPane.setAlignment(top, Pos.TOP_CENTER);
        Button bottom = new Button("Bottom");
        BorderPane.setAlignment(bottom, Pos.BOTTOM_CENTER);
        Button center = new Button("Center");
        BorderPane root = new BorderPane(center,top,right,bottom,left);
        Scene scene = new Scene(root,300,150);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}