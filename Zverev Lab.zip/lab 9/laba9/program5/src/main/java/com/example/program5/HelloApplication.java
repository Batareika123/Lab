package com.example.program5;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        Button btn = new Button();
        Button button = new Button();
        button.setText("click");
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                button.setText("You've clicked!!!!!!");
            }
        });
        btn.setText("click");
        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                btn.setText("You've clicked!");
            }
        });
        Group root = new Group(btn, button);
        Scene scene = new Scene(root);
        stage.setTitle("Hello!");
        btn.setLayoutX(100);
        btn.setLayoutY(50);
        stage.setWidth(250);
        stage.setHeight(200);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}