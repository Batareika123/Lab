module com.example.program10 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.program10 to javafx.fxml;
    exports com.example.program10;
}