module com.example.program9 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.program9 to javafx.fxml;
    exports com.example.program9;
}