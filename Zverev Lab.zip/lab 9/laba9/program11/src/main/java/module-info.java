module com.example.program11 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.program11 to javafx.fxml;
    exports com.example.program11;
}