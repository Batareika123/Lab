package com.example.program11;

import javafx.application.Application;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.FlowPane;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;

import javafx.geometry.Orientation;
import javafx.beans.value.ObservableValue;
import javafx.beans.value.ChangeListener;

import java.io.IOException;


public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        Label selectedLbl = new Label();
        TextField textField= new TextField();
        ObservableList<String> langs = FXCollections.observableArrayList("Java","JavaScript","C#","Python");
        ListView<String> langsListView = new ListView<String>(langs);
        langsListView.setPrefSize(250,150);
        Button add = new Button("Add");
        Button delete = new Button("Delete");
        FlowPane buttonPane = new FlowPane(10,10,textField,add,delete);
        add.setOnAction(event -> langs.add(textField.getText()));
        delete.setOnAction(event -> langs.remove(textField.getText()));
        MultipleSelectionModel<String> langsSelectionModel = langsListView.getSelectionModel();
        langsSelectionModel.setSelectionMode(SelectionMode.MULTIPLE);
        langsSelectionModel.selectedItemProperty().addListener(new ChangeListener<String>() {
            public void changed(ObservableValue<? extends String> changed,String oldValue, String newValue) {
                String selectedItems = "";
                ObservableList<String> seleced = langsSelectionModel.getSelectedItems();
                for(String item : seleced){
                    selectedItems += item + "";
                }
                selectedLbl.setText("Selected: " + selectedItems);
            }
        });
        FlowPane root = new FlowPane(Orientation.VERTICAL,10,10, selectedLbl,buttonPane, langsListView);
        Scene scene = new Scene(root,300,250);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}