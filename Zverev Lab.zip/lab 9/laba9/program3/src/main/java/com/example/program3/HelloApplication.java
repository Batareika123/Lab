package com.example.program3;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        Label label = new Label("Hello");
        Button button = new Button("tik");
        Button buttons = new Button("button");

        Group groups = new Group(buttons);
        Group group = new Group(button);
        Group roots = new Group(label,group,groups);
        Scene scene = new Scene(roots, 500,500, Color.BLUE);
        label.setLayoutY(30);
        label.setLayoutX(30);
        button.setLayoutY(150);
        button.setLayoutX(30);
        buttons.setLayoutY(80);
        buttons.setLayoutX(30);
        button.setPrefSize(50,50);
        buttons.setPrefSize(100,50);
        stage.setScene(scene);
        stage.setTitle("hello javafx");
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}