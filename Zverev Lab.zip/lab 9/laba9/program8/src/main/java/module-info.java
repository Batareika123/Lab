module com.example.program8 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.program8 to javafx.fxml;
    exports com.example.program8;
}