package com.example.program8;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    CheckBox java;
    CheckBox javaScriot;
    CheckBox csharp;
    Label selectedLangs;
    private CheckBox javaScript;

    public static void main(String[] args) {
        Application.launch(args);
        
    }

    @Override
    public void start(Stage stage) throws IOException {

        CheckBox java = new CheckBox("Java");
        java.setAllowIndeterminate(true);
        CheckBox javaScript = new CheckBox("JavaScript");
        javaScript.setAllowIndeterminate(true);
        CheckBox csharp = new CheckBox("C#");
        csharp.setAllowIndeterminate(true);
        csharp.setIndeterminate(true);
        FlowPane root = new FlowPane(Orientation.VERTICAL,0,10);
        root.getChildren().addAll(java, javaScript, csharp);
        root.setPadding(new Insets(10));
        Scene scene = new Scene(root,250, 200);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }


}